package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.beans.EmployeePeoject;
import com.hefshine.dao.ProjectDAO;


public class ProjectDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int  id=Integer.parseInt(request.getParameter("project_id"));
		
		ProjectDAO pd=new ProjectDAO();
		List<EmployeePeoject> mylist=pd.getById(id);
		
		PrintWriter writer=response.getWriter();
		
		writer.write("<table border='1px'>");
					writer.write("<tr>");
							writer.write("<td>Project_id</td>");
							writer.write("<td>Project_name</td>");
							writer.write("<td>employee_id</td>");
							writer.write("<td>employee_name</td>");
							writer.write("<td>getDetail</td>");
					writer.write("</tr>");
					
					for(EmployeePeoject ep:mylist)
					{
						writer.write("<tr>");
								writer.write("<td>"+ep.getProjectId()+"</td>");
								writer.write("<td>"+ep.getProjectName()+"</td>");
								writer.write("<td>"+ep.getEmployeeId()+"</td>");
								writer.write("<td>"+ep.getEmployeeName()+"</td>");
								writer.write("<td><a href='EmployeeDetails?employee_name="+ep.getEmployeeName()+"'>Get</a></td></tr>");
								
				        writer.write("</tr>");
				
					}
		
		
		writer.write("</table>");
		
		
		
		
		
		
	}

}
