package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.beans.Employee;
import com.hefshine.dao.BridgeDAO;
import com.hefshine.dao.EmployeeDAO;


public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int  id=Integer.parseInt(request.getParameter("id"));
		String Name=request.getParameter("name");
		int age=Integer.parseInt(request.getParameter("age"));
		String gender=request.getParameter("gender");
		int contactnumber=Integer.parseInt(request.getParameter("pnumber"));
		
		String [] projects=request.getParameterValues("projectname");
		
		
		Employee employee=new Employee();
		employee.setId(id);
		employee.setName(Name);
		employee.setAge(age);
		employee.setGender(gender);
		employee.setContact(contactnumber);
	
		
		EmployeeDAO ed=new EmployeeDAO();
		
		BridgeDAO bd=new BridgeDAO();
		
		ed.save(employee);
		bd.save(employee, projects);
		
		
		PrintWriter writer=response.getWriter();
		
		writer.write("insert successfully");
		
		
		
		
	}

}
