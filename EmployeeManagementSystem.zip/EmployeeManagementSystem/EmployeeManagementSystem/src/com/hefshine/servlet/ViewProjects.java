package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.beans.Project;
import com.hefshine.dao.ProjectDAO;


public class ViewProjects extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		ProjectDAO pd=new ProjectDAO();
		
		List<Project> mylist=pd.getAll();
		
		
		PrintWriter writer=response.getWriter();
		
		writer.write("<table border='1px'>");
		        writer.write("<tr>");
						writer.write("<td>project_id</td>");
						writer.write("<td>project_name</td>");
						writer.write("<td>GetDetail</td>");
				writer.write("</tr>");
		
				for(Project project:mylist)
				{
					 writer.write("<tr>");
						writer.write("<td>"+project.getId()+"</td>");
						writer.write("<td>"+project.getName()+"</td>");
						writer.write("<td><a href='ProjectDetails?project_id="+project.getId()+"'>Get</a></td>");
				writer.write("</tr>");
		
				}
		
		
		writer.write("</table>");
		
		
		
	}

}
