package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.beans.Employee;
import com.hefshine.dao.EmployeeDAO;


public class EmployeeDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String name=request.getParameter("employee_name");
		EmployeeDAO ed=new EmployeeDAO();
		
		List<Employee>  mylist=ed.getByName(name);
		
		PrintWriter writer=response.getWriter();
		
		writer.write("<a href='welcome.html'>Wlecome</a>");
		
		writer.write("<table border='1px'>");
		writer.write("<tr><td>employee_id</td>");
		writer.write("<td>employee_name</td>");
		writer.write("<td>project_name</td></tr>");
		
		for(Employee s:mylist)
		{
			writer.write("<tr><td>"+s.getId()+"</td>");
			writer.write("<td>"+s.getName()+"</td>");
			writer.write("<td>"+s.getProject()+"</td></tr>");
			
		}

writer.write("</table>");

		
		
		
		
	}

}
