package com.hefshine.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hefshine.dao.EmployeeDAO;


public class ViewEmployees extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		PrintWriter writer=response.getWriter();
		
		/*writer.write("<form action='EmployeeDetails'>");
		
		writer.write("Name: <input type='text' name='name'>");
		writer.write("<input type='submit' value='submit'>");
		
		writer.write("</form>");*/
		
		EmployeeDAO ed=new EmployeeDAO();
		
		List<String> mylist=ed.getAll();
		
		writer.write("<table border='1px'>");
				writer.write("<tr><td>Name</td>");
				writer.write("<td>Get</td></tr>");
				
				for(String s:mylist)
				{
					writer.write("<tr><td>"+s+"</td>");
					writer.write("<td><a href='EmployeeDetails?employee_name="+s+"'>Get</a></td></tr>");
					
				}
		
		writer.write("</table>");
		
	}

}
