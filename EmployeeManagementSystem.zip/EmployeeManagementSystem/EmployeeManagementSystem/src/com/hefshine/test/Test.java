package com.hefshine.test;

import java.util.List;

import com.hefshine.beans.EmployeePeoject;
import com.hefshine.dao.ProjectDAO;

public class Test {
public static void main(String[] args) {
	
	ProjectDAO pd=new ProjectDAO();
	List<EmployeePeoject> mylist=pd.getById(1);
	
	for(EmployeePeoject ep:mylist)
	{
		System.out.println(ep);
	}
	
	
	
}
}
