package com.hefshine.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.hefshine.beans.Employee;

public class BridgeDAO {
	private String URL_DB="jdbc:oracle:thin:@localhost:1522:xe";
	private String USERNAME="nhl";
	private String PASSWORD="root";
	
	
	 public void save(Employee employee,String projects[])
	    {
	    	try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
				
				String query="INSERT INTO bridge1 VALUES(?,?)";
				PreparedStatement pst=connection.prepareStatement(query);
				for(int i=0;i<projects.length;i++)
				{
					pst.setInt(1,employee.getId());
					pst.setInt(2, i+1
							);
					pst.executeUpdate();
				}
				
				
				
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
	    }

	
	

}
