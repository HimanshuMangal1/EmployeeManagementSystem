package com.hefshine.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hefshine.beans.EmployeePeoject;
import com.hefshine.beans.Project;

public class ProjectDAO {

	
	private String URL_DB="jdbc:oracle:thin:@localhost:1522:xe";
	private String USERNAME="nhl";
	private String PASSWORD="root";
	
	
	
	public List<Project> getAll()
	{
		List<Project> mylist=new ArrayList<Project>();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
			
			String query="SELECT * FROM projects1";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Project project=new Project();
				
				project.setId(rs.getInt("project_id"));
				project.setName(rs.getString("project_name"));
				
				
				
				
				mylist.add(project);
			}
			
			
			
			
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return mylist;
		
	}



  public List<EmployeePeoject> getById(int id)
  {
	  List<EmployeePeoject> mylist=new ArrayList<EmployeePeoject>();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
			
			String query="select  p.project_id,p.project_name ,e.employee_id,e.employee_name " + 
					" from employees1 e" + 
					" join Bridge1 b on(e.employee_id=b.e_id)" + 
					" join  projects1 p" + 
					" on (p.project_id=b.p_id)" + 
					" where p.project_id=?";
			
			PreparedStatement pst=connection.prepareStatement(query);
			pst.setInt(1, id);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				EmployeePeoject ep=new EmployeePeoject();
				
				ep.setProjectId(rs.getInt(1));
				ep.setProjectName(rs.getString(2));
				ep.setEmployeeId(rs.getInt(3));
				ep.setEmployeeName(rs.getString(4));
				
				
				
				mylist.add(ep);
			}
			
			
			
			
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return mylist;

	
	  
  }


}
