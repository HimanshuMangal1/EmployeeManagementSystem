package com.hefshine.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hefshine.beans.Employee;


public class EmployeeDAO {
	
	private String URL_DB="jdbc:oracle:thin:@localhost:1522:xe";
	private String USERNAME="nhl";
	private String PASSWORD="root";
	
	
	public List<String> getAll()
	{
		List<String> mylist=new ArrayList<String>();
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
			
			String query="SELECT employee_name FROM employees1";
			
			PreparedStatement pst=connection.prepareStatement(query);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				
				String Name=rs.getString("employee_name");
				mylist.add(Name);
			}
			
			
			
			
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return mylist;
		
	}

	
	public List<Employee> getByName(String Name)
	{
		List<Employee>  mylist=new ArrayList<Employee> ();
		
		
		
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
			
			String query=" select  e.employee_id,e.employee_name,p.project_name " + 
					" from employees1 e " + 
					" join Bridge1 b on(e.employee_id=b.e_id) " + 
					" join  projects1 p " + 
					" on (p.project_id=b.p_id) " + 
					" where e.employee_name=?";
			
			PreparedStatement pst=connection.prepareStatement(query);
			pst.setString(1, Name);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{   Employee employee=new Employee();
				employee.setId(rs.getInt("employee_id"));
				employee.setName(rs.getString("employee_name"));
				employee.setProject(rs.getString("project_name"));
				
				mylist.add(employee);
			}
			
			
			
			
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return mylist;
		
	}

    public void save(Employee employee)
    {
    	try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection connection=DriverManager.getConnection(URL_DB,USERNAME,PASSWORD);
			
			String query="INSERT INTO employees1 VALUES(?,?,?,?,?)";
			PreparedStatement pst=connection.prepareStatement(query);
			pst.setInt(1,employee.getId());
			pst.setString(2, employee.getName());
			pst.setInt(3, employee.getAge());
			pst.setString(4, employee.getGender());
			pst.setInt(5, employee.getContact());
			
			
			
			pst.executeUpdate();
			
			
			
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
    }

}
