package com.hefshine.beans;

public class EmployeePeoject {

	private int projectId;
	private String projectName;
	private int employeeId;
	private String employeeName;
	public EmployeePeoject() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeePeoject(int projectId, String projectName, int employeeId, String employeeName) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.employeeId = employeeId;
		this.employeeName = employeeName;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	@Override
	public String toString() {
		return "EmployeePeoject [projectId=" + projectId + ", projectName=" + projectName + ", employeeId=" + employeeId
				+ ", employeeName=" + employeeName + "]";
	}
	
	



}
